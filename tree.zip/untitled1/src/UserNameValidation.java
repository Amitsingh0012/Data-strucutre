import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
class UsernameValidator {
    /*
     * Write regular expression here.
     */
    private static final String USERNAME_PATTERN ="^[a-zA-Z0-9](_-](?![_-])|[a-zA-Z0-9]){8,30}[a-zA-Z0-9]$";

    private static final Pattern pattern = Pattern.compile(USERNAME_PATTERN);

    public static boolean isValid(final String username) {
        Matcher matcher = pattern.matcher(username);
        return matcher.matches();
    }

    public static final String regularExpression = null;
}


public class UserNameValidation {
    private static final Scanner scan = new Scanner(System.in);

    public static void main(String[] args) {
        int n = Integer.parseInt(scan.nextLine());
        while (n-- != 0) {
            String userName = scan.nextLine();

            if (userName.matches(UsernameValidator.regularExpression)) {
                System.out.println("Valid");
            } else {
                System.out.println("Invalid");
            }
        }
    }
}