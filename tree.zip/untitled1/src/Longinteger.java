import java.io.*;
import java.util.*;
import java.text.*;
import java.math.*;
import java.util.regex.*;

public class Longinteger {

    public static void main(String[] args) {
        /* Enter your code here. Read input from STDIN. Print output to STDOUT. Your class should be named Solution. */
        Scanner input = new Scanner(System.in);

        BigInteger a = input.nextBigInteger();
        BigInteger b = input.nextBigInteger();
        BigInteger sum,mul;
        sum=a.add(b);
        mul=a.multiply(b);
        System.out.println(sum);
        System.out.println(mul);
    }
}
