import java.util.Scanner;

public class Salary {
        public static void main(String[] args){
            Scanner sc=new Scanner(System.in);
            int salary=20000;
            int service=6;
            int bonus=0;
            bonus=salary*5/100;
            System.out.println(bonus);
            if(service>5){

            }else{

            }
        }

}
