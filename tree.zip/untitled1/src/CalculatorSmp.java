public class CalculatorSmp {
}
