import java.util.Scanner;

public class ReverseNumber {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter your number");
        int n=sc.nextInt();
        int z=n;
        int k=0;
        int newNumber=0;
        while(n>0){
            n=n/10;
            k++;
        }
        for(int i=0;i<k;i++){
            int r=z%10;
            z=z/10;
            newNumber=newNumber*10+r;
        }
        System.out.println(newNumber);

    }
}
