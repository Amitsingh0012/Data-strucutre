public class HourGlass {
    public static void main(String[] args){

    }
}
