import java.util.Scanner;

public class OneToTen {
    public static void main(String[] arg){
        Scanner sc=new Scanner(System.in);
        System.out.println("Enter a number");
        int i=sc.nextInt();
        int n=1;
        int sum=0;
        while (n<=i){
            sum+=n;
            n++;
        }
        System.out.println(sum);
    }
}
