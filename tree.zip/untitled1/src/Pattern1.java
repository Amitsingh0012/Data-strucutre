import java.util.Scanner;

public class Pattern1 {
    public static void main(String[] args){
        Scanner sc= new Scanner(System.in);
        System.out.println("Enter your number");
        int n=sc.nextInt();
        int num=1;
        for(int j = 0; j < (n); j++) {
            for(int i = 0; i < num; i++) {
                System.out.print(" ");
            }
            for(int i = (n)/2; i > j; i--) {
                System.out.print("_");
            }

            num += 2;
            System.out.println();
            if(num>n){
                break;
            }
        }
    }
}
