import java.util.Scanner;

public class EvenSUmOddProduct {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        System.out.println("enter your number");
        int num= sc.nextInt();
        int sum=0,prod=1;
        if(num%2==0){
            while (num>0){
                sum+=num%10;
                num=num/10;
            }
            System.out.println("Sum is "+sum);
        }else{
            while (num>0){
                prod*=(num%10);
                num=num/10;
            }
            System.out.println("Product is "+prod);
        }
    }
}
