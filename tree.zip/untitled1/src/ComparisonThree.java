public class ComparisonThree {
    public static void main(String[] arg){
        int a=9;
        int b=13;
        int c=16;
        if(a>b){
            if(a>c){
                System.out.println(" A is greater");
            }
        }else{
            if(b>c){
                System.out.println("B is greater");
            }else {
                System.out.println("c is greater");
            }
        }

    }
}
