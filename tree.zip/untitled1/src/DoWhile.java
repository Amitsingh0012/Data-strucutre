public class DoWhile {
    public static void main(String[] args){

    }
}
