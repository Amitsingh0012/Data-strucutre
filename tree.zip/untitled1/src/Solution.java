import java.util.Stack;

class Solution {
    public static boolean isValid(String s) {
        Stack<Character> stc=new Stack<>();
        for(int i=0;i<s.length();i++){
            char ch=s.charAt(i);
                if(!stc.isEmpty() && stc.peek()=='('&& ch==')'){
                    System.out.println(stc.pop());
                }else if(!stc.isEmpty() && stc.peek()=='{'&& ch=='}'){
                    System.out.println(stc.pop());
                }else if(!stc.isEmpty() && stc.peek()=='['&& ch==']'){
                    System.out.println(stc.pop());
                }else
                    stc.push(ch);
        }
        return stc.isEmpty();
    }

    public static void main(String[] args) {
        System.out.println(isValid("({[)"));
    }
}