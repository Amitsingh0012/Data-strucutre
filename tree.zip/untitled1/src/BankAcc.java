import javax.sound.midi.Soundbank;
import java.util.Scanner;

public class BankAcc {
    public static void main(String[] args){
        Scanner sc=new Scanner(System.in);
        int ammount=0;
        int totalAmmount=5500;
        System.out.println("Enter your ATM");
        System.out.println("choose your account type");
        System.out.println("press 1 for saving");
        System.out.println("press 2 for current");
        int z=sc.nextInt();
        if(z==1){
            System.out.println("welcome to saving account");
        }else if(z==2){
            System.out.println("welcome to current account");
        }
        else{
            System.out.println("Invalid input");
        }
        System.out.println("1 : balance Enquiry ");
        System.out.println("2 : Withdrawl");
        System.out.println("3 : Deposite");
        System.out.println("4 : Exit");
        int n=sc.nextInt();
        switch (n){
            case 1:
                System.out.println("Your balance is :"+totalAmmount);
                break;
            case 2:
                System.out.println("Enter ammount to withdrawl :");
                int s=sc.nextInt();
                if(totalAmmount>=s){
                    totalAmmount-=s;
                    if(totalAmmount<=2000)
                        totalAmmount+=s;
                    System.out.println("Successfully withdrawl remaining ammount ="+totalAmmount);
                }else{
                    System.out.println("Insufficient fund");
                }
                break;
            case 3:
                System.out.println("enter ammount you want to deposite");
                ammount=sc.nextInt();
                totalAmmount+=ammount;
                if(totalAmmount>ammount){
                    System.out.println("Deposite unsuccessful");
                }else{
                    System.out.println("ammount deposited successfully");
                    System.out.println(totalAmmount);
                }
            case 4:
                System.out.println("Exit sucessfully");

        }
    }

}
