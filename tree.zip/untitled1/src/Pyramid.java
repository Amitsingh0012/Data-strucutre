public class Pyramid {
    public static void main(String[] args){
        for(int i=5;i>0;i--){
            for(int j=i;j>0;j--){
                for(int k=0;k<i-5;k++){
                    System.out.println(" ");
                }
                System.out.print(" * ");
            }
            System.out.println();
        }
    }
}
