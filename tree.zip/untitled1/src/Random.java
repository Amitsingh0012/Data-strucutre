public class Random {
    public static void main(String[] agr){
        int randomNumber=(int)(Math.random()*5)+1;
        System.out.println("Random number is :"+randomNumber);
    }
}
