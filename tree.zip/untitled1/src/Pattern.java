import java.util.Scanner;

public class Pattern {
    public static void main(String[] arg){
        Scanner sc=new Scanner(System.in);
        int n=sc.nextInt();
        for(int j=1;j<n;j++){
            for(int k=1;k<=n+4;k++){
                if(k==1||k==n+4){
                    System.out.print("*");
                }else{
                    System.out.print(" ");
                }
            }
            System.out.println("");
        }
        for(int i=1;i<=n+4;i++){
            System.out.print("*");
        }
        System.out.println();
        int num=1;
        for(int j = 0; j < (n+4)/2; j++) {
            for(int i = (n+4)/2; i > j; i--) {
                System.out.print(" ");
            }
            for(int i = 0; i < num; i++) {
                System.out.print("@");
            }
            num += 2;
            System.out.println();
            if(num>n){
                break;
            }
        }
    }
}
